#pragma once

#define HTTP_SERVER "178.211.130.203"
#define HTTP_PORT 80

#define TFTP_SERVER "178.211.130.203"
